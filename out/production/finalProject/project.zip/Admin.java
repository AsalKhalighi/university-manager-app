public class Admin extends User{
    Admin(String name, String surname, int age, String ID) {
        super(name, surname, age, ID);
    }


    public void addNews(){
        //TODO
        }
    public void removeNews(){
        //TODO
         }
    public void addCourse(){
        //TODO
    }
    public void removeCourse(){
        //TODO
    }
}
