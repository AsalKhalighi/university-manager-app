import java.util.List;
import java.util.Map;

public class Student {
    int numberOfCourses;
    int tedadVahed;
    List<Course> courses;
    List<Double> scores;
    double totalAverage;
    double termAverage;
    String studentId;
    void printTotalAverage(){
        System.out.println("moadel kol is: "+totalAverage);
    }
    void printCourses(){
        System.out.println("List doros sabt nami is:\n "+courses);
    }
    void printTedadVahed(){
        System.out.println("tedad vahed sabt nami is: "+tedadVahed);
    }
    void settingScores(){
        for (int i =0;i<courses.size();i++){
            scores.add(courses.get(i).getTeacher().nomredehi(this));
        }
    }


}
