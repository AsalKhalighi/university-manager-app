import java.util.ArrayList;
import java.util.List;

public class Admin extends User{
    Admin(String name, String surname, int age, String ID, String email, String phoneNumber, String password) {
        super(name, surname, age, ID, phoneNumber, email);

    }

HomePage homePage = new HomePage();
    public void addNews(String text){
        uni.setNews(text);
    }

    public void removeNews(String text){
        uni.getNews().removeIf(i -> i == text);
         }
    public void addCourse(Course course){
        List<Course> courses = uni.getCourses();
        for(Course course1: courses){
            if(course1.equals(course)){
                System.out.println("The course already exists!");
                return;
            }
        }
        courses.add(course);
        uni.setCourses(courses);
        System.out.println("Course added successfully!");
    }
    public void removeCourse(Course course){
        List<Course> courses = uni.getCourses();
        for(Course course1:courses){
            if(course1.equals(course)){
                courses.remove(course);
                uni.setCourses(courses);
                System.out.println("Removed successfully!");
                return;
            }
        }
        System.out.println("This course does not exists!");
    }
}
