import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
public class HomePage {


    Uni uni = new Uni();


    Scanner scanner = new Scanner(System.in);
    boolean logout = false;

    public  void loggedIn(User user){
        if(user instanceof Student){
            while (!logout){
                Student student = (Student) user;
                int choice = 8;
                boolean success = false;
                while (!success){
                    try{
                        System.out.println("\n--------HomePage-------");
                        System.out.println("please choose your page: ");
                        System.out.println(" 1- User Information");
                        System.out.println(" 2- Courses");
                        System.out.println(" 3- Assignments");
                        System.out.println(" 4- Exams");
                        System.out.println(" 5- Grades");
                        System.out.println(" 6- TODO");
                        System.out.println(" 7- Log out");
                        choice = scanner.nextInt();
                        success = true;
                    }catch (Exception e){
                        System.out.println("Enter a number!!");
                        scanner.nextLine();
                    }
                }
                boolean back = false;
                switch (choice){
                    case 1:
                        while (!back){
                            System.out.println("Name: "+student.getName());
                            System.out.println("Surname: "+student.getSurname());
                            System.out.println("Age: "+student.getAge());
                            System.out.println("Student ID: "+student.getID());
                            System.out.println("Major: "+student.getMajor());
                            System.out.println("Phone number: "+student.getPhoneNumber());
                            System.out.println("Email: "+student.getEmail());

                            System.out.println("For editing your information please press '1' and for going back enter '2'");
                            boolean s1 = false;
                            int editingChoice = 0;
                            while (!s1){
                                try{
                                    editingChoice = scanner.nextInt();
                                    s1 = true;
                                }
                                catch (Exception e){
                                    System.out.println("Enter a number!!");
                                    scanner.nextLine();
                                }
                            }

                            if(editingChoice==2){
                                back = true;
                                break;
                            }
                            else if (editingChoice == 1){
                                System.out.println("Chose what You want to change: " +
                                        "1.Name\n" +
                                        "2.surname\n" +
                                        "3.Age\n" +
                                        "4.Email\n" +
                                        "5.phone number\n" +
                                        "6.Major\n" +
                                        "7.password\n" +
                                        "8.Back\n");
                                int edit = scanner.nextInt();
                                switch (edit){
                                    case 1 :
                                        System.out.println("Please enter your name: ");
                                        String name = scanner.next();
                                        student.setName(name);
                                        System.out.println("Your name successfully changed to "+student.getName());
                                        break;
                                    case 2:
                                        System.out.println("Please Enter your surname: ");
                                        String surname = scanner.next();
                                        student.setSurnameName(surname);
                                        System.out.println("Your surname successfully changed to "+student.getSurname());
                                        break;
                                    case 3:
                                        boolean s2 = false;
                                        while (!s2){
                                            try{
                                                System.out.println("please enter your age: ");
                                                int age = scanner.nextInt();
                                                student.setAge(age);
                                                System.out.println("Your age successfully changed to "+student.getAge());
                                                s2 =true;
                                                break;
                                            }catch (Exception e){
                                                System.out.println("Please enter a number!!");
                                                scanner.nextLine();
                                            }

                                        }

                                    case 4:
                                        System.out.println("please enter your Email: ");
                                        String email = scanner.next();
                                        student.setEmail(email);
                                        System.out.println("your Email successfully changed to "+student.getEmail());
                                        break;
                                    case 5:
                                        System.out.println("Please Enter your phone number");
                                        String phoneNumber = scanner.next();
                                        student.setPhoneNumber(phoneNumber);
                                        System.out.println("your phone number successfully changed to "+student.getPhoneNumber());
                                        break;
                                    case 6:
                                        System.out.println("please Enter your new Major");
                                        String major = scanner.next();
                                        student.setMajor(major);
                                        System.out.println("Your major successfully changed to "+student.getMajor());
                                        break;
                                    case 7:
                                        System.out.println("Please enter Your current password");
                                        String cpass = scanner.next();
                                        if(student.getPassword().equals(cpass)){
                                            System.out.println("Please Enter your new password");
                                            String npass = scanner.next();
                                            student.setPassword(npass);
                                            System.out.println("your password successfully changed to "+npass);
                                            break;
                                        }
                                        else{
                                            for(int i=0;i<3;i++){
                                                System.out.println("Your pass word is not correct, please try again");
                                                System.out.println("try's left: "+(2-i));
                                                cpass = scanner.next();
                                                if(student.getPassword().equals(cpass)){
                                                    System.out.println("Please Enter your new password");
                                                    String npass = scanner.next();
                                                    student.setPassword(npass);
                                                    System.out.println("your password successfully changed to "+student.getPassword());
                                                    break;
                                                }
                                            }
                                            System.out.println("Your password was not correct. For security safety you can't stay logged in, please make contact with Admin.");
                                            back = true;
                                            logout = true;
                                            break;
                                        }
                                    case 8:
                                        logout = true;
                                        break;

                                }
                            }
                        }
                        break;
                    case 2:
                        //show list of course with the teachers name and number of vahed
                        back = false;
                        while (!back){
                            boolean s = false;
                            int courseChoice = 0;
                            while(!s){
                                try{
                                    System.out.println("Please choose your choice: ");
                                    System.out.println(" 1- Courses Information");
                                    System.out.println(" 2- Adding Courses");
                                    System.out.println(" 3- Deleting Courses");
                                    System.out.println(" 4- Back");
                                    courseChoice = scanner.nextInt();
                                    s = true;
                                }
                                catch (Exception e){
                                    System.out.println("Please enter a number!!");
                                    scanner.nextLine();
                                }
                            }

                            List<Course> courses = student.getCourses();
                            switch (courseChoice){
                                case 1:
                                    for(int i=0;i<courses.size();i++){
                                        System.out.println("-----------------------");
                                        System.out.println("Name: "+courses.get(i).getName());
                                        System.out.println("Teacher: "+courses.get(i).getTeacher());
                                        System.out.println("Tedad vahed: "+courses.get(i).getVahed());
                                        System.out.println("Course ID: "+courses.get(i).getCourseID());
                                        System.out.println("Exam date: "+courses.get(i).getExamDate());
                                        System.out.println("Term: "+courses.get(i).getTerm());
                                        System.out.println("Your score in this course: "+student.getCourseGrades().get(courses.get(i)));
                                    }
                                    break;
                                case 2:
                                    System.out.println("Enter the course name: ");
                                    String name = scanner.next();
                                    System.out.println("Enter the teacher name: ");
                                    String teacherName = scanner.next();
                                    System.out.println("Enter the teacher surname: ");
                                    String teacherSurname = scanner.next();
                                    boolean foundteacher = false;
                                    Teacher teacher1 = null;
                                    int vahedNum =0;
                                    while(!foundteacher){
                                        for(User user1: uni.getUsers()){
                                            if(user1 instanceof Teacher && user1.getName().equals(teacherName)&&user1.getSurname().equals(teacherSurname)){
                                                teacher1 = (Teacher) user1;
                                                foundteacher=true;
                                                System.out.println("Enter the vahed number: ");
                                                boolean s1 = false;

                                                while (!s1){
                                                    try{
                                                        vahedNum = scanner.nextInt();
                                                        s1 =true;
                                                    }
                                                    catch (Exception e){
                                                        System.out.println("Enter a number!!");
                                                        scanner.nextLine();
                                                    }
                                                }
                                                break;
                                            }
                                        }
                                        if(!foundteacher){
                                            System.out.println("The teacher doesn't Exist!");
                                            break;
                                        }

                                    }


                                    Course c1 =new Course(name,teacher1,vahedNum);
                                    boolean foundCourse = false;
                                    for (Course course: uni.courses){
                                        if(course.equals(c1)){
                                            student.addCourse(c1);
                                            System.out.println("The course has been added to your courses successfully.");
                                            foundCourse = true;
                                            break;
                                        }
                                    }
                                    if(!foundCourse){
                                        System.out.println("The course was not found.Try again.");
                                        break;
                                    }
                                    else {
                                        break;
                                    }
                                case 3:
                                    System.out.println("Enter the course name: ");
                                    String dname = scanner.next();
                                    System.out.println("Enter the teacher surname: ");
                                    String dteacherSurname = scanner.next();
                                    System.out.println("Enter the teacher name: ");
                                    String dteacherName = scanner.next();
                                    boolean dfoundteacher = false;
                                    Teacher dteacher1 = null;
                                    while(!dfoundteacher){
                                        for(User user1: uni.getUsers()){
                                            if(user1 instanceof Teacher && user1.getName().equals(dteacherName)&&user1.getSurname().equals(dteacherSurname)){
                                                dteacher1 = (Teacher) user1;
                                                dfoundteacher=true;
                                                break;
                                            }
                                        }
                                        System.out.println("The teacher doesn't exist!");
                                    }
                                    System.out.println("Enter the vahed number: ");
                                    boolean s2 = false;
                                    int dvahedNum =0;
                                    while (!s2){
                                        try{
                                            dvahedNum = scanner.nextInt();
                                            s2 = true;
                                        }
                                        catch (Exception e){
                                            System.out.println("Enter a number!!");
                                            scanner.nextLine();
                                        }
                                    }

                                    Course dc1 =new Course(dname,dteacher1,dvahedNum);
                                    boolean dfound = false;
                                    while (!dfound){
                                        for(Course course:student.getCourses()){
                                            if(course.equals(dc1)){
                                                student.removeCourse(dc1);
                                                dfound = true;
                                                System.out.println("Course removed successfully!");
                                            }
                                        }
                                        if(!dfound){
                                            System.out.println("The course doesn't exists!");
                                            break;
                                        }
                                        else {
                                            break;
                                        }
                                    }
                                case 4:
                                    back =true;
                                    break;
                            }
                        }
                        break;

                    case 3:
                        //show the title of assignment and days left until deadline
                        for (Course c2 : student.getCourses()){
                            for(Assignment assignment: c2.getAssignments()){
                                System.out.println(c2.getName()+" : "+assignment.assignmentName+" , "+assignment.deadline+" , "+assignment.daysLeft);
                            }
                            System.out.println();
                        }

                        break;

                    case 4:
                        //show the coursename of the exam and deadline and details of the exam(boodjehbandi)
                        for (Course c2 : student.getCourses()){
                            System.out.println(c2.getName()+" : "+c2.getExamDate()+" , "+c2.getExamDetail());
                        }

                        break;
                    case 5:
                        //show a list of courses with their grades, the totalGradeAvg, the highest and the lowest grade
                        for(Course course:student.getCourses()){
                            System.out.println(course.getName()+" : "+student.getCourseGrades().get(course)+","+course.calculateHighestGradeINCourse()+","+course.calculateTotalGradesAvgInCourse()+","+course.calculateLowestScoreInCourse());
                        }

                        break;
                    case 6:
                        //1- show to do list
                        //2- edit to do list
                        while (!back) {
                            System.out.println("-----------------------");
                            System.out.println("TODO List: ");
                            for (int i=0;i<user.getTODO().size();i++) {
                                System.out.println(user.getTODO().get(i));
                            }

                            System.out.println("\n-----------------------");
                            System.out.println("Please choose your action: ");
                            System.out.println(" 1- Edit TODO List");
                            System.out.println(" 2- Back");
                            boolean s =false;
                            int option =0;
                            while (!s){
                                try{
                                    option = scanner.nextInt();
                                    s = true;
                                }
                                catch (Exception e){
                                    System.out.println("Enter a number!!");
                                    scanner.nextLine();
                                }
                            }

                            String task;


                            switch (option) {

                                case 1:
                                    System.out.println("Please choose your action: ");
                                    System.out.println(" 1- Add Task");
                                    System.out.println(" 2- Remove task");
                                    boolean s1 = false;
                                    int o =0;
                                    while(!s1){
                                        try{
                                            o = scanner.nextInt();
                                            s1 =true;
                                        }
                                        catch (Exception e){
                                            System.out.println("Please enter a number!!");
                                            scanner.nextLine();
                                        }
                                    }

                                    switch (o){
                                        case 1:
                                    System.out.println("Write down the task you want to add: ");
                                    scanner.nextLine();
                                    task = scanner.nextLine();
                                    user.getTODO().add(task);
                                    System.out.println("TODO List successfully updated!");
                                    break;
                                        case 2:
                                    System.out.println("Write down the task you want to remove: ");
                                    scanner.nextLine();
                                    task = scanner.nextLine();
                                    user.getTODO().remove(task);
                                    System.out.println("TODO List successfully updated!");
                                    break;
                                        default:
                                        System.out.println("Invalid choice");
                                    }

                                        break;
                                case 2:
                                    back = true;
                                    break;

                                default:
                                    System.out.println("Invalid choice");

                            }
                        }
                        break;

                    case 7:
                        logout = true;
                        break;

                    default:
                        System.out.println("Invalid choice");
                        break;
                }
            }

        }
        else if(user instanceof Teacher){
            while (!logout){
                Teacher teacher = (Teacher) user;
                int choice = 8;
                boolean success = false;
                while (!success){
                    try{
                        System.out.println("\n--------HomePage-------");
                        System.out.println("please choose your page: ");
                        System.out.println(" 1- User Information");
                        System.out.println(" 2- Courses");
                        System.out.println(" 3- Assignments");
                        System.out.println(" 4- Exams");
                        System.out.println(" 5- Grades");
                        System.out.println(" 6- TODO");
                        System.out.println(" 7- Log out");
                        choice = scanner.nextInt();
                        success = true;
                    }catch (Exception e){
                        System.out.println("Enter a number!!");
                        scanner.nextLine();
                    }
                }
                boolean back = false;
                switch (choice){
                    case 1:
                        while (!back){
                            System.out.println("Name: "+teacher.getName());
                            System.out.println("Surname: "+teacher.getSurname());
                            System.out.println("Age: "+teacher.getAge());
                            System.out.println("Teacher ID: "+teacher.getID());
                            System.out.println("Phone number: "+teacher.getPhoneNumber());
                            System.out.println("Email: "+teacher.getEmail());

                            System.out.println("For editing your information please press '1' and for going back enter '2'");
                            boolean s1 = false;
                            int editingChoice = 0;
                            while (!s1){
                                try{
                                    editingChoice = scanner.nextInt();
                                    s1 = true;
                                }
                                catch (Exception e){
                                    System.out.println("Enter a number!!");
                                    scanner.nextLine();
                                }
                            }

                            if(editingChoice==2){
                                back = true;
                                break;
                            }
                            else if (editingChoice == 1){
                                System.out.println("Chose what You want to change: " +
                                        "1.Name\n" +
                                        "2.surname\n" +
                                        "3.Age\n" +
                                        "4.Email\n" +
                                        "5.phone number\n" +
                                        "6.password\n" +
                                        "7.Back\n");
                                int edit = scanner.nextInt();
                                switch (edit){
                                    case 1 :
                                        System.out.println("Please enter your name: ");
                                        String name = scanner.next();
                                        teacher.setName(name);
                                        System.out.println("Your name successfully changed to "+teacher.getName());
                                        break;
                                    case 2:
                                        System.out.println("Please Enter your surname: ");
                                        String surname = scanner.next();
                                        teacher.setSurnameName(surname);
                                        System.out.println("Your surname successfully changed to "+teacher.getSurname());
                                        break;
                                    case 3:
                                        boolean s2 = false;
                                        while (!s2){
                                            try{
                                                System.out.println("Please enter your age: ");
                                                int age = scanner.nextInt();
                                                teacher.setAge(age);
                                                System.out.println("Your age successfully changed to "+teacher.getAge());
                                                s2 =true;
                                                break;
                                            }catch (Exception e){
                                                System.out.println("Please enter a number!!");
                                                scanner.nextLine();
                                            }

                                        }

                                    case 4:
                                        System.out.println("Please enter your Email: ");
                                        String email = scanner.next();
                                        teacher.setEmail(email);
                                        System.out.println("Your email successfully changed to "+teacher.getEmail());
                                        break;
                                    case 5:
                                        System.out.println("Please enter your phone number");
                                        String phoneNumber = scanner.next();
                                        teacher.setPhoneNumber(phoneNumber);
                                        System.out.println("your phone number successfully changed to "+teacher.getPhoneNumber());
                                        break;
                                    case 6:
                                        System.out.println("Please enter Your current password");
                                        String cpass = scanner.next();
                                        if(teacher.getPassword().equals(cpass)){
                                            System.out.println("Please Enter your new password");
                                            String npass = scanner.next();
                                            teacher.setPassword(npass);
                                            System.out.println("Your password successfully changed to "+npass);
                                            break;
                                        }
                                        else{
                                            for(int i=0;i<3;i++){
                                                System.out.println("Your pass word is not correct, please try again");
                                                System.out.println("try's left: "+(2-i));
                                                cpass = scanner.next();
                                                if(teacher.getPassword().equals(cpass)){
                                                    System.out.println("Please Enter your new password");
                                                    String npass = scanner.next();
                                                    teacher.setPassword(npass);
                                                    System.out.println("your password successfully changed to "+teacher.getPassword());
                                                    break;
                                                }
                                            }
                                            System.out.println("Your password was not correct. For security safety you can't stay logged in, please make contact with Admin.");
                                            back = true;
                                            logout = true;
                                            break;
                                        }
                                    case 7:
                                        logout = true;
                                        break;

                                }
                            }
                        }
                        break;
                    case 2:
                        //show list of course with the teachers name and number of vahed
                        back = false;
                        while (!back){
                            boolean s = false;
                            int courseChoice = 0;
                            while(!s){
                                try{
                                    System.out.println("Please choose your choice: ");
                                    System.out.println(" 1- Courses Information");
                                    System.out.println(" 2- Adding Courses");
                                    System.out.println(" 3- Deleting Courses");
                                    System.out.println(" 4- Back");
                                    courseChoice = scanner.nextInt();
                                    s = true;
                                }
                                catch (Exception e){
                                    System.out.println("Please enter a number!!");
                                    scanner.nextLine();
                                }
                            }

                            List<Course> courses = teacher.getTeacherCourses();
                            switch (courseChoice){
                                case 1:
                                    for(int i=0;i<courses.size();i++){
                                        System.out.println("-----------------------");
                                        System.out.println("Name: "+courses.get(i).getName());
                                        //TODO
                                        //List of students
                                        System.out.println("Tedad vahed: "+courses.get(i).getVahed());
                                        System.out.println("Course ID: "+courses.get(i).getCourseID());
                                        System.out.println("Exam date: "+courses.get(i).getExamDate());
                                        System.out.println("Term: "+courses.get(i).getTerm());
                                        //TODO
                                        //highest score in each course
                                    }
                                    break;
                                case 2:
                                    System.out.println("Enter the course name: ");
                                    String name = scanner.next();
                                    System.out.println("Enter the teacher name: ");
                                    String teacherName = scanner.next();
                                    System.out.println("Enter the teacher surname: ");
                                    String teacherSurname = scanner.next();
                                    boolean foundteacher = false;
                                    Teacher teacher1 = null;
                                    while(!foundteacher){
                                        for(User user1: uni.getUsers()){
                                            if(user1 instanceof Teacher && user1.getName().equals(teacherName)&&user1.getSurname().equals(teacherSurname)){
                                                teacher1 = (Teacher) user1;
                                                foundteacher=true;
                                                break;
                                            }
                                        }
                                        System.out.println("The teacher doesn't Exist!");
                                    }
                                    System.out.println("Enter the vahed number: ");
                                    boolean s1 = false;
                                    int vahedNum =0;
                                    while (!s1){
                                        try{
                                            vahedNum = scanner.nextInt();
                                            s1 =true;
                                        }
                                        catch (Exception e){
                                            System.out.println("Enter a number!!");
                                            scanner.nextLine();
                                        }
                                    }

                                    Course c1 =new Course(name,teacher1,vahedNum);
                                    boolean foundCourse = false;
                                    for (Course course: uni.courses){
                                        if(course.equals(c1)){
                                            teacher.addCourse(c1);
                                            System.out.println("The course has been added to your courses successfully.");
                                            foundCourse = true;
                                            break;
                                        }
                                    }
                                    if(!foundCourse){
                                        System.out.println("The course was not found.Try again.");
                                        break;
                                    }
                                    else {
                                        break;
                                    }
                                case 3:
                                    System.out.println("Enter the course name: ");
                                    String dname = scanner.next();
                                    System.out.println("Enter the teacher surname: ");
                                    String dteacherSurname = scanner.next();
                                    System.out.println("Enter the teacher name: ");
                                    String dteacherName = scanner.next();
                                    boolean dfoundteacher = false;
                                    Teacher dteacher1 = null;
                                    while(!dfoundteacher){
                                        for(User user1: uni.getUsers()){
                                            if(user1 instanceof Teacher && user1.getName().equals(dteacherName)&&user1.getSurname().equals(dteacherSurname)){
                                                dteacher1 = (Teacher) user1;
                                                dfoundteacher=true;
                                                break;
                                            }
                                        }
                                        System.out.println("The teacher doesn't exist!");
                                    }
                                    System.out.println("Enter the vahed number: ");
                                    boolean s2 = false;
                                    int dvahedNum =0;
                                    while (!s2){
                                        try{
                                            dvahedNum = scanner.nextInt();
                                            s2 = true;
                                        }
                                        catch (Exception e){
                                            System.out.println("Enter a number!!");
                                            scanner.nextLine();
                                        }
                                    }

                                    Course dc1 =new Course(dname,dteacher1,dvahedNum);
                                    boolean dfound = false;
                                    while (!dfound){
                                        for(Course course:teacher.getTeacherCourses()){
                                            if(course.equals(dc1)){
                                                teacher.removeCourse(dc1);
                                                dfound = true;
                                                System.out.println("Course removed successfully!");
                                            }
                                        }
                                        if(!dfound){
                                            System.out.println("The course doesn't exists!");
                                            break;
                                        }
                                        else {
                                            break;
                                        }
                                    }
                                case 4:
                                    back =true;
                                    break;
                            }
                        }
                        break;

                    case 3:
                        //show the title of assignment and days left until deadline
                        for (Course c2 : teacher.getTeacherCourses()){
                            for(Assignment assignment: c2.getAssignments()){
                                System.out.println(c2.getName()+" : "+assignment.assignmentName+" , "+assignment.deadline+" , "+assignment.daysLeft);
                            }
                            System.out.println();
                        }

                        break;

                    case 4:
                        //show the coursename of the exam and deadline and details of the exam(boodjehbandi)
                        for (Course c2 : teacher.getTeacherCourses()){
                            System.out.println(c2.getName()+" : "+c2.getExamDate()+" , "+c2.getExamDetail());
                        }

                        break;
                    case 5:
                        //show a list of courses with their grades, the totalGradeAvg, the highest and the lowest grade
                       //TODO

                        break;
                    case 6:
                        //1- show to do list
                        //2- edit to do list
                        while (!back) {
                            System.out.println("-----------------------");
                            System.out.println("TODO List: ");
                            for (int i=0;i<user.getTODO().size();i++) {
                                System.out.println(user.getTODO().get(i));
                            }

                            System.out.println("\n-----------------------");
                            System.out.println("Please choose your action: ");
                            System.out.println(" 1- Edit TODO List");
                            System.out.println(" 2- Back");
                            boolean s =false;
                            int option =0;
                            while (!s){
                                try{
                                    option = scanner.nextInt();
                                    s = true;
                                }
                                catch (Exception e){
                                    System.out.println("Enter a number!!");
                                    scanner.nextLine();
                                }
                            }

                            String task;


                            switch (option) {

                                case 1:
                                    System.out.println("Please choose your action: ");
                                    System.out.println(" 1- Add Task");
                                    System.out.println(" 2- Remove task");
                                    boolean s1 = false;
                                    int o =0;
                                    while(!s1){
                                        try{
                                            o = scanner.nextInt();
                                            s1 =true;
                                        }
                                        catch (Exception e){
                                            System.out.println("Please enter a number!!");
                                            scanner.nextLine();
                                        }
                                    }

                                    switch (o){
                                        case 1:
                                            System.out.println("Write down the task you want to add: ");
                                            scanner.nextLine();
                                            task = scanner.nextLine();
                                            user.getTODO().add(task);
                                            System.out.println("TODO List successfully updated!");
                                            break;
                                        case 2:
                                            System.out.println("Write down the task you want to remove: ");
                                            scanner.nextLine();
                                            task = scanner.nextLine();
                                            user.getTODO().remove(task);
                                            System.out.println("TODO List successfully updated!");
                                            break;
                                        default:
                                            System.out.println("Invalid choice");
                                    }

                                    break;
                                case 2:
                                    back = true;
                                    break;

                                default:
                                    System.out.println("Invalid choice");

                            }
                        }
                        break;

                    case 7:
                        logout = true;
                        break;

                    default:
                        System.out.println("Invalid choice");
                        break;
                }
            }
            }

        else if(user instanceof Admin) {
            Admin admin = (Admin) user;
            boolean back = false;

            while (!logout) {

                System.out.println("\n--------HomePage-------");
                System.out.println("please choose your page: ");
                System.out.println(" 1- User Information");
                System.out.println(" 2- Edit Information");
                System.out.println(" 3- Courses");
                System.out.println(" 4- Exams");
                System.out.println(" 5- Grades");
                System.out.println(" 6- TODO");
                System.out.println(" 7- News");
                System.out.println(" 8- Log out");

                int choice = scanner.nextInt();
                switch (choice) {

                    case 1:
                        //1- show information
                        //2- edit information {ask what they wanna edit: 1-pass? 2-email? 3-...}

                    case 2:


                    case 3:

                    case 4:

                    case 5:

                    case 6:

                    case 7:


                        while (!back) {
                            System.out.println("Please choose your action: ");
                            System.out.println(" 1- See News");
                            System.out.println(" 2- Add News");
                            System.out.println(" 3- Remove News");
                            System.out.println(" 4- Back");
                            int option = scanner.nextInt();
                            String text;


                            switch (option) {

                                case 1:
                                    for (int i=0;i<uni.getNews().size();i++) {
                                        System.out.println(uni.getNews());
                                    }
                                    break;
                                case 2:
                                    System.out.println("Write down the News you want to add: ");
                                    scanner.nextLine();
                                    text = scanner.nextLine();
                                    admin.addNews(text);
                                    System.out.println("News successfully updated!");
                                    break;
                                case 3:
                                    System.out.println("Write down the News you want to remove: ");
                                    scanner.nextLine();
                                    text = scanner.nextLine();
                                    admin.removeNews(text);
                                    System.out.println("News successfully updated!");
                                    break;
                                case 4:
                                    back = true;
                                    break;

                                default:
                                    System.out.println("Invalid choice");

                            }
                        }
                        break;


                    case 8:
                        logout = true;
                        break;

                    default:
                        System.out.println("Invalid choice");
                }
            }
        }




    }



}
