public class Admin extends User{
    Admin(String name, String surname, int age, String ID) {
        super(name, surname, age, ID);
    }
}
