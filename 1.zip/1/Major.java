import java.util.ArrayList;
import java.util.List;

public class Major {
    String majorName;
    List<Course> courses = new ArrayList<>();
}
