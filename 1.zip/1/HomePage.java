import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
public class HomePage {

    List<String> News = new ArrayList<>();

    Scanner scanner = new Scanner(System.in);
    boolean logout = false;
    Uni uni = new Uni();


    public  void loggedIn(User user){
        if(user instanceof Student){
            Student student = (Student) user;
            System.out.println("\n--------HomePage-------");
            System.out.println("please choose your page: ");
            System.out.println(" 1- User Information");
            System.out.println(" 2- Courses");
            System.out.println(" 3- Assignments");
            System.out.println(" 4- Exams");
            System.out.println(" 5- Grades");
            System.out.println(" 6- TODO");
            System.out.println(" 7- News");
            System.out.println(" 8- Log out");
            int choice = scanner.nextInt();
            boolean back = false;
            switch (choice){
                case 1:
                    while (!back){
                        System.out.println("Name: "+student.getName());
                        System.out.println("Surname: "+student.getSurname());
                        System.out.println("Age: "+student.getAge());
                        System.out.println("Student ID: "+student.getID());
                        System.out.println("Major: "+student.getMajor());
                        System.out.println("Phone number: "+student.getPhoneNumber());
                        System.out.println("Email: "+student.getEmail());

                        System.out.println("For editing your information please press one and for going back enter two");
                        int editingChoice =scanner.nextInt();
                        if(editingChoice==2){
                            back = true;
                            break;
                        }
                        else if (editingChoice == 1){
                            System.out.println("Chose what You want to change: " +
                                    "1.Name\n" +
                                    "2.surname\n" +
                                    "3.Age\n" +
                                    "4.Email\n" +
                                    "5.phone number\n" +
                                    "6.Major\n" +
                                    "7.password\n" +
                                    "8.Back\n");
                            int edit = scanner.nextInt();
                            switch (edit){
                                case 1 :
                                    System.out.println("Please enter your name: ");
                                    String name = scanner.next();
                                    student.setName(name);
                                    System.out.println("Your name successfully changed to "+student.getName());
                                    break;
                                case 2:
                                    System.out.println("Please Enter your surname: ");
                                    String surname = scanner.next();
                                    student.setSurnameName(surname);
                                    System.out.println("Your surname successfully changed to "+student.getSurname());
                                    break;
                                case 3:
                                    System.out.println("please enter your age: ");
                                    int age = scanner.nextInt();
                                    student.setAge(age);
                                    System.out.println("Your age successfully changed to "+student.getAge());
                                    break;
                                case 4:
                                    System.out.println("please enter your Email: ");
                                    String email = scanner.next();
                                    student.setEmail(email);
                                    System.out.println("your Email successfully changed to "+student.getEmail());
                                    break;
                                case 5:
                                    System.out.println("Please Enter your phone number");
                                    String phoneNumber = scanner.next();
                                    student.setPhoneNumber(phoneNumber);
                                    System.out.println("your phone number successfully changed to "+student.getPhoneNumber());
                                    break;
                                case 6:
                                    System.out.println("please Enter your new Major");
                                    String major = scanner.next();
                                    student.setMajor(major);
                                    System.out.println("Your major successfully changed to "+student.getMajor());
                                    break;
                                case 7:
                                    System.out.println("Please enter Your current password");
                                    String cpass = scanner.next();
                                    if(student.getPassword().equals(cpass)){
                                        System.out.println("Please Enter your new password");
                                        String npass = scanner.next();
                                        student.setPassword(npass);
                                        System.out.println("your password successfully changed to "+npass);
                                        break;
                                    }
                                    else{
                                        for(int i=0;i<3;i++){
                                            System.out.println("Your pass word is not correct, please try again");
                                            System.out.println("try's left: "+(2-i));
                                            cpass = scanner.next();
                                            if(student.getPassword().equals(cpass)){
                                                System.out.println("Please Enter your new password");
                                                String npass = scanner.next();
                                                student.setPassword(npass);
                                                System.out.println("your password successfully changed to "+student.getPassword());
                                                break;
                                            }
                                        }
                                        System.out.println("your password was not correct.For security safety you cant stay logged in,please make contact with Admin");
                                        back = true;
                                        logout = true;
                                        break;
                                    }
                                case 8:
                                    logout = true;
                                    break;

                            }
                        }
                    }
                    break;
                case 2:
                    //show list of course with the teachers name and number of vahed
                    back = false;
                    while (!back){
                        System.out.println("please choose your choice: ");
                        System.out.println("1.Courses information");
                        System.out.println("2.Adding courses");
                        System.out.println("3.deleting courses");
                        System.out.println("4.Back");
                        int courseChoice = scanner.nextInt();
                        List<Course> courses = student.getCourses();
                        switch (courseChoice){
                            case 1:
                                for(int i=0;i<courses.size();i++){
                                    System.out.println("-----------------------");
                                    System.out.println("Name: "+courses.get(i).getName());
                                    System.out.println("Teacher: "+courses.get(i).getTeacher());
                                    System.out.println("Tedad vahed: "+courses.get(i).getVahed());
                                    System.out.println("Course ID: "+courses.get(i).getCourseID());
                                    System.out.println("Exam date: "+courses.get(i).getExamDate());
                                    System.out.println("Term: "+courses.get(i).getTerm());
                                    System.out.println("Your score in this course: "+student.getCourseGrades().get(courses.get(i)));
                                }
                                break;
                            case 2:
                                System.out.println("Enter the course name: ");
                                String name = scanner.next();
                                System.out.println("Enter the Teacher surname: ");
                                String teacherSurname = scanner.next();
                                System.out.println("Enter the Teacher name: ");
                                String teacherName = scanner.next();
                                boolean foundteacher = false;
                                Teacher teacher1 = null;
                                while(!foundteacher){
                                    for(User user1: uni.getUsers()){
                                        if(user1 instanceof Teacher && user1.getName().equals(teacherName)&&user1.getSurname().equals(teacherSurname)){
                                            teacher1 = (Teacher) user1;
                                            foundteacher=true;
                                            break;
                                        }
                                    }
                                    System.out.println("The teacher doesnt Exist!");
                                }
                                System.out.println("Enter the vahed number: ");
                                int vahedNum = scanner.nextInt();
                                Course c1 =new Course(name,teacher1,vahedNum);
                                boolean foundCourse = false;
                                for (Course course: uni.courses){
                                    if(course.equals(c1)){
                                        student.addCourse(c1);
                                        System.out.println("The course has been added to your courses successfully.");
                                        foundCourse = true;
                                        break;
                                    }
                                }
                                if(!foundCourse){
                                    System.out.println("the course was not found.Try again.");
                                    break;
                                }
                                else {
                                    break;
                                }
                            case 3:
                                System.out.println("Enter the course name: ");
                                String dname = scanner.next();
                                System.out.println("Enter the Teacher surname: ");
                                String dteacherSurname = scanner.next();
                                System.out.println("Enter the Teacher name: ");
                                String dteacherName = scanner.next();
                                boolean dfoundteacher = false;
                                Teacher dteacher1 = null;
                                while(!dfoundteacher){
                                    for(User user1: uni.getUsers()){
                                        if(user1 instanceof Teacher && user1.getName().equals(dteacherName)&&user1.getSurname().equals(dteacherSurname)){
                                            dteacher1 = (Teacher) user1;
                                            dfoundteacher=true;
                                            break;
                                        }
                                    }
                                    System.out.println("The teacher doesnt Exist!");
                                }
                                System.out.println("Enter the vahed number: ");
                                int dvahedNum = scanner.nextInt();
                                Course dc1 =new Course(dname,dteacher1,dvahedNum);
                                boolean dfound = false;
                                while (!dfound){
                                    for(Course course:student.getCourses()){
                                        if(course.equals(dc1)){
                                            student.removeCourse(dc1);
                                            dfound = true;
                                            System.out.println("successful!");
                                        }
                                    }
                                    if(!dfound){
                                        System.out.println("The course does not exists!");
                                        break;
                                    }
                                    else {
                                        break;
                                    }
                                }
                            case 4:
                                back =true;
                                break;
                        }
                    }
                    break;

                case 3:
                    //show the title of assignment and days left until deadline
                        for (Course c2 : student.getCourses()){
                            for(Assignment assignment: c2.getAssignments()){
                                System.out.println(c2.getName()+" : "+assignment.assignmentName+" , "+assignment.deadline+" , "+assignment.daysLeft);
                            }
                            System.out.println();
                        }

                        break;

                case 4:
                    //show the coursename of the exam and deadline and details of the exam(boodjehbandi)
                    for (Course c2 : student.getCourses()){
                        System.out.println(c2.getName()+" : "+c2.getExamDate()+" , "+c2.getExamDetail());
                        }

                    break;
                case 5:
                    //show a list of courses with their grades, the totalGradeAvg, the highest and the lowest grade
                    for(Course course:student.getCourses()){
                        System.out.println(course.getName()+" : "+student.getCourseGrades().get(course)+","+course.calculateHighestGradeINCourse()+","+course.calculateTotalGradesAvgInCourse()+","+course.calculateLowestScoreInCourse());
                    }

                    break;
                case 6:
                    //1- show to do list
                    //2- edit to do list
                    break;
                case 7:
                    //print news
                    break;
                case 8:
                    logout = true;
                    break;
                default:
                    System.out.println("Invalid choice");
            }
        }
        else if(user instanceof Teacher){
            Teacher teacher = (Teacher) user;
            System.out.println("\n--------HomePage-------");
            System.out.println("please choose your page: ");
            System.out.println(" 1- User Information");
            System.out.println(" 2- Courses");
            System.out.println(" 3- Assignments");
            System.out.println(" 4- Exams");
            System.out.println(" 5- Grades");
            System.out.println(" 6- TODO");
            System.out.println(" 7- News");
            System.out.println(" 8- Log out");

            int choice = scanner.nextInt();
            switch (choice) {

                case 1:
                    //1- show information
                    //2- edit information {ask what they wanna edit: 1-pass? 2-email? 3-...}

                case 2:


                case 3:

                case 4:

                case 5:

                case 6:

                case 7:

                case 8:
                    logout = true;
                    break;

                default:
                    System.out.println("Invalid choice");
            }
        }
        else if(user instanceof Admin){
            Admin admin = (Admin) user;
            System.out.println("\n--------HomePage-------");
            System.out.println("please choose your page: ");
            System.out.println(" 1- User Information");
            System.out.println(" 2- Edit Information");
            System.out.println(" 3- Courses");
            System.out.println(" 4- Exams");
            System.out.println(" 5- Grades");
            System.out.println(" 6- TODO");
            System.out.println(" 7- News");
            System.out.println(" 8- Log out");

            int choice = scanner.nextInt();
            switch (choice) {

                case 1:
                    //1- show information
                    //2- edit information {ask what they wanna edit: 1-pass? 2-email? 3-...}

                case 2:


                case 3:

                case 4:

                case 5:

                case 6:

                case 7:

                case 8:
                    logout = true;
                    break;

                default:
                    System.out.println("Invalid choice");
            }
        }





    }
}
