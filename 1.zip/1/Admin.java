public class Admin extends User{
    Admin(String name, String surname, int age, String ID,String phoneNumber,String email) {
        super(name, surname, age, ID,phoneNumber,email);
    }


    public void addNews(){
        //TODO
        }
    public void removeNews(){
        //TODO
         }
    public void addCourse(){
        //TODO
    }
    public void removeCourse(){
        //TODO
    }
}
